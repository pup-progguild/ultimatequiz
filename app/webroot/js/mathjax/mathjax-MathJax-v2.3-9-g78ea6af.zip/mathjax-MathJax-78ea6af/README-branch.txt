This is release branch v2.3 of MathJax.
